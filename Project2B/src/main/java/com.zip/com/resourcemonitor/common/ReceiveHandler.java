package com.resourcemonitor.common;

public interface ReceiveHandler {
    public void onMessage(MonitorData m);
}
