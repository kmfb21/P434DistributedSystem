package com.resourcemonitor.common;

public class MonitorException extends Exception {
    public MonitorException(String s, Throwable throwable) {
        super(s, throwable);
    }
}
